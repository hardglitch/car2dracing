using UnityEngine;

public class OnItemCollision : MonoBehaviour
{
    private CarScript _carScript;
    public CarScript Car
    {
        get => _carScript;
        set
        {
            _carScript = value;
            _carScript = Car;
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        _carScript.OnItemCollision(collision);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        _carScript.OnItemCollision(collision);
    }
}