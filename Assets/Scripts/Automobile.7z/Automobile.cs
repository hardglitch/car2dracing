﻿using System;
using UnityEngine;

public class Automobile : MonoBehaviour
{
    [Header("Car Parameters")]
    [SerializeField] private float acceleration = 200;
    [SerializeField] private float maxSpeed = 1500;
    [SerializeField] private float inertia = 2;

    //private protected GameObject CarPrefab { get; set; }

    //private protected GameObject CarIcon { get; set; }

    private readonly WheelJoint2D[] _wheelJoints = new WheelJoint2D[2];
    private JointMotor2D _wheels;
    private AngleTimer _angleTimer;
    private Controllers _controllers;

    public bool IsCompetitor { get; set; }

    public bool IsFinished { get; set; }


    private void Awake()
    {
        _angleTimer = gameObject.AddComponent<AngleTimer>();
        _controllers = gameObject.AddComponent<Controllers>();

        throw new NotImplementedException();
    }


    private void FixedUpdate() //TODO: Replace FixedUpdate to Players.cs
    {
        // ReSharper disable once Unity.PerformanceCriticalCodeInvocation
        AutomobileMovement();
    }

    private void AutomobileMovement()
    {
        if (!IsCompetitor)
        {
            try
            {
                // Forward Move (Right)
                if (_controllers.IsClickedRight() && _wheels.motorSpeed >= -maxSpeed)
                {
                    if (_wheels.motorSpeed > 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed -= acceleration * Time.fixedDeltaTime;
                }
                else if (!_controllers.IsClickedLeft() && _wheels.motorSpeed < 0)
                    _wheels.motorSpeed += acceleration * inertia * Time.fixedDeltaTime;


                // Back Move (Left)
                if (_controllers.IsClickedLeft() && _wheels.motorSpeed <= maxSpeed)
                {
                    if (_wheels.motorSpeed < 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed += acceleration * Time.fixedDeltaTime;
                }
                else if (!_controllers.IsClickedRight() && _wheels.motorSpeed > 0)
                    _wheels.motorSpeed -= acceleration * inertia * Time.fixedDeltaTime;

                _wheelJoints[1].motor = _wheels; // backWheel = frontWheel
                _wheelJoints[0].motor = _wheels;

                _angleTimer.AngleChecker();
            }
            catch (Exception error)
            {
                // ReSharper disable once Unity.PerformanceCriticalCodeInvocation
                Debug.LogError(error);
            }
        }

        else
        
        if (_currentHealth > 0 && !IsFinished)
        {
            try
            {
                // Forward Move (Right)
                if (_wheels.motorSpeed >= -maxSpeed &&
                    transform.rotation.z < 0.5f)
                {
                    if (_wheels.motorSpeed >= -maxSpeed)
                        _wheels.motorSpeed = -maxSpeed;
                    else
                    if (_wheels.motorSpeed > 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed -= acceleration * Time.fixedDeltaTime;
                }
                else
                // Back Move (Left)
                {
                    if (_wheels.motorSpeed >= maxSpeed)
                        _wheels.motorSpeed = maxSpeed;
                    else
                    if (_wheels.motorSpeed < 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed += acceleration * Time.fixedDeltaTime;
                }

                _wheelJoints[1].motor = _wheels; // backWheel = frontWheel
                _wheelJoints[0].motor = _wheels;
            }
            catch (Exception error)
            {
                // ReSharper disable once Unity.PerformanceCriticalCodeInvocation
                Debug.LogError(error);
            }

            _angleTimer.AngleChecker();
        }
        else
        {
            _wheels.motorSpeed = 0;
            _wheelJoints[1].motor = _wheels; // backWheel = frontWheel
            _wheelJoints[0].motor = _wheels;
        }
    }
}