using UnityEngine;

//TODO: Remake CarScript.cs
public class CarScript : PlayerOperations
{
    private SfxManager _sfxManager;
    private Scoreboard _scoreBoard;


    public void SetSfxManager(SfxManager sfx)
    { _sfxManager = sfx; }

    public void SetScoreboard(Scoreboard scoreBoard)
    { _scoreBoard = scoreBoard; }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("MaxX"))  // Finish
        {
            GetComponent<Competitor>().SetIsFinished(true);
            _scoreBoard.PushPlaceholderValue(gameObject.name);

            //Finish Scene
            if (gameObject.layer == LayerMask.NameToLayer("Player")) Finish();
        }

        OnItemCollision(collision);
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        OnItemCollision(collision);
    }

  
    public void OnItemCollision(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Coin"))
        {
            Destroy(collision.gameObject);
            SetCoins(+1);
            ShowCoinsUI();
            _sfxManager.PlayCoinSfx();
        }

        if (!collision.gameObject.CompareTag("HP")) return;
        Destroy(collision.gameObject);
        RecountHealth(+1);
    }


    public void OnItemCollision(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Coin"))
        {
            Destroy(collision.gameObject);
            SetCoins(+1);
            ShowCoinsUI();
            _sfxManager.PlayCoinSfx();
        }

        if (!collision.gameObject.CompareTag("HP")) return;
        Destroy(collision.gameObject);
        RecountHealth(+1);
    }
}
