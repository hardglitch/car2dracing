﻿using UnityEngine;

public class PlayerOperations : MonoBehaviour
{
    private const int MAXHealth = 3;
    protected int CurrentHealth = MAXHealth;
    private int _coins;

    protected void RecountHealth(int deltaHealth)
    {
        CurrentHealth += deltaHealth;

        if (CurrentHealth <= 0)
        {
            CurrentHealth = 0;
            GetComponent<Hud>().MakeRestartScreen();
        }

        if (CurrentHealth > MAXHealth)
            CurrentHealth = MAXHealth;

        Hud.MakeHp();
    }


    protected int GetCoins()
    {
        return _coins;
    }

    
    protected void SetCoins(int coins)
    {
        _coins += coins;
    }


    protected int GetHealth()
    {
        return CurrentHealth;
    }
}