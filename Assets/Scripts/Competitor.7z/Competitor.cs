using System;
using UnityEngine;

public class Competitor : MonoBehaviour
{
    private WheelJoint2D[] _wheelJoints;
    private JointMotor2D _wheels;

    private const float Acceleration = 200;
    private const float MAXSpeed = 1500;

    private const float AngleTimer = 5;
    private float _angleTime;

    private const int MAXHealth = 3;
    private int _currentHealth;
    private int _coins;

    private bool _isFinished;


    private void Start()
    {
        _wheelJoints = GetComponents<WheelJoint2D>();
        _wheels = _wheelJoints[0].motor;
        _currentHealth = MAXHealth;
        _angleTime = AngleTimer;
    }


    private void FixedUpdate()
    {
        if (_currentHealth > 0 && !_isFinished)
        {
            try
            {
                // Forward Move (Right)
                if (_wheels.motorSpeed >= -MAXSpeed &&
                    transform.rotation.z < 0.5f)
                {
                    if (_wheels.motorSpeed >= -MAXSpeed)
                        _wheels.motorSpeed = -MAXSpeed;
                    else
                    if (_wheels.motorSpeed > 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed -= Acceleration * Time.fixedDeltaTime;
                }
                else
                // Back Move (Left)
                {
                    if (_wheels.motorSpeed >= MAXSpeed)
                        _wheels.motorSpeed = MAXSpeed;
                    else
                    if (_wheels.motorSpeed < 0)
                        _wheels.motorSpeed = 0;
                    else
                        _wheels.motorSpeed += Acceleration * Time.fixedDeltaTime;
                }

                _wheelJoints[1].motor = _wheels; // backWheel = frontWheel
                _wheelJoints[0].motor = _wheels;
            }
            catch (Exception error)
            {
                // ReSharper disable once Unity.PerformanceCriticalCodeInvocation
                Debug.LogError(error);
            }

            AngleChecker();
        }
        else
        {
            _wheels.motorSpeed = 0;
            _wheelJoints[1].motor = _wheels; // backWheel = frontWheel
            _wheelJoints[0].motor = _wheels;
        }
    }


    private void AngleChecker()
    {
        if (Mathf.Abs(transform.rotation.z) > 0.5f)
        {
            _angleTime -= Time.fixedDeltaTime;

            if (!(_angleTime <= 0)) return;
            if (_currentHealth > 1)
            {
                transform.position = new Vector3(transform.position.x, transform.position.y + 2f, transform.position.z);
                transform.rotation = Quaternion.Euler(0, 0, 0);
                _angleTime = AngleTimer;
            }
            RecountHealth(-1);
        }
        else
            _angleTime = AngleTimer;
    }


    private void RecountHealth(int deltaHealth)
    {
        _currentHealth += deltaHealth;

        if (_currentHealth <= 0)
        {
            _currentHealth = 0;
        }
        if (_currentHealth > MAXHealth)
            _currentHealth = MAXHealth;
    }


    public void SetIsFinished(bool isFinish)
    {
        _isFinished = isFinish;
    }

    public bool GetIsFinished()
    {
        return _isFinished;
    }

    public int GetCoins()
    {
        return _coins;
    }

    public void SetCoins(int coins)
    {
        _coins += coins;
    }


    public int GetHealth()
    {
        return _currentHealth;
    }
}