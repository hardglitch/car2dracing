using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class MenuLevels : MonoBehaviour
{

    [Serializable]
    public class ScrollingElement
    {
        public Button _Button { get { return _Button; } set { _Button = value; } }

        [SerializeField] private Button privateButton;
        [HideInInspector] public Vector2 position = new Vector2();
        [HideInInspector] public Vector2 scale = new Vector2();
        [HideInInspector] public float originalScaleX;
        [HideInInspector] public string Time_buttonText = "00:00", Coins_buttonText = "00000";

        private MenuLevels _GO;
        [HideInInspector] public RectTransform rect;

        public ScrollingElement() 
        {
            _Button = privateButton;
            _Button.interactable = false;
            print("2222");
            //originalScaleX = _button.GetComponent<RectTransform>().localScale.x;
            //Time_buttonText = _GO.transform.Find("Time").GetComponent<TMP_Text>().text;
            //print("111 ="+_GO.transform.Find("Time").GetComponent<TMP_Text>().text);
            //Coins_buttonText = _GO.transform.Find("Coins").GetComponent<TMP_Text>().text;


            //rect = _button.GetComponent<RectTransform>();
        }

        public ScrollingElement(
            MenuLevels _GO
            )
        {
            this._GO = _GO;
        }
    }


    [Header("Scrolling Content")]
    [SerializeField] private ScrollingElement[] scrollElements;

    [Range(1, 300)]
    [SerializeField] private int scrollElementsDistance;

    [Range(0, 20)]
    [SerializeField] private float snapSpeed;

    [Range(0, 5)]
    [SerializeField] private float scaleOffset;

    [Range(0, 20)]
    [SerializeField] private float scaleSpeed;

    [Header("Other Objects")]

    [SerializeField] private ScrollRect scrollRect;

    private RectTransform contentRect;
    private int selectedScrollElementsID;
    private bool isScrolling;
    private Vector2 contentVector;
    private int scrollElementsCounter;


/*
    void Start()
    {
        scrollElementsCounter = scrollElements.Length;
        contentRect = GetComponent<RectTransform>();

        for (int i=0; i<scrollElementsCounter; i++)
        {
            try
            {
                // get coins value
                if (PlayerPrefs.HasKey("Coins" + (i + 1).ToString()))
                    scrollElements[i].Coins_buttonText = PlayerPrefs.GetInt("Coins" + (i + 1).ToString()).ToString("D5");

                // get time value
                if (PlayerPrefs.HasKey("Time" + (i + 1).ToString()))
                    scrollElements[i].Time_buttonText = ShowGameTime(PlayerPrefs.GetFloat("Time" + (i + 1).ToString()));

                // set level settings
                if (PlayerPrefs.HasKey("Level") && i <= PlayerPrefs.GetInt("Level") || i == 0)
                    scrollElements[i].button.interactable = true;

                // draw level screen
                scrollElements[i].rect.anchoredPosition = new Vector2(
                    (scrollElements[i].rect.sizeDelta.x + scrollElementsDistance) * i, 0);

                scrollElements[i].position = -scrollElements[i].rect.anchoredPosition;
            }
            catch (Exception error)
            {
                Debug.LogError(error);
            }
        }
    }


    void FixedUpdate()
    {
        if ((contentRect.anchoredPosition.x <= scrollElements[0].position.x ||
            contentRect.anchoredPosition.x >= scrollElements[scrollElementsCounter - 1].position.x) &&
            !isScrolling)
            scrollRect.inertia = false;


        float nearestPos = float.MaxValue;
        for (int i = 0; i < scrollElementsCounter; i++)
        {
            float distance = Mathf.Abs(contentRect.anchoredPosition.x - scrollElements[i].position.x);
            if (distance < nearestPos)
            {
                nearestPos = distance;
                selectedScrollElementsID = i;
            }

            Vector2 imageScale = scrollElements[i].rect.localScale;

            float scale = Mathf.Clamp(
                scrollElements[i].originalScaleX / (distance / scrollElementsDistance) * scaleOffset, 
                0.5f * scrollElements[i].originalScaleX,
                scrollElements[i].originalScaleX);

            scrollElements[i].scale = new Vector2(
                Mathf.SmoothStep(imageScale.x, scale, scaleSpeed * Time.fixedDeltaTime),
                Mathf.SmoothStep(imageScale.y, scale, scaleSpeed * Time.fixedDeltaTime));

            scrollElements[i].rect.localScale = scrollElements[i].scale;
        }

        float scrollVelocity = Mathf.Abs(scrollRect.velocity.x);

        if (!isScrolling || scrollVelocity < 400)
        {
            scrollRect.inertia = false;

            contentVector.x = Mathf.SmoothStep(
                contentRect.anchoredPosition.x,
                scrollElements[selectedScrollElementsID].position.x,
                snapSpeed * Time.fixedDeltaTime);

            contentRect.anchoredPosition = contentVector;
        }
    }


    public void Scrolling(bool scrolling)
    {
        isScrolling = scrolling;
        if (isScrolling) scrollRect.inertia = true;
    }


    public string ShowGameTime(float gameTime)
    {
        int minutes = (int)gameTime / 60;
        int seconds = (int)gameTime - ((int)gameTime / 60) * 60;

        return minutes.ToString("00") + ":" + seconds.ToString("00");
    }


    public void DeleteAllKeys()
    {
        PlayerPrefs.DeleteAll();
    }
*/
}
