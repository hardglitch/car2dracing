using UnityEngine;
using System;

public class Controllers : MonoBehaviour
{
    public class ButtonPosition
    {
        private Transform button;
        private Vector2 buttonSize;

        public void GetButton(GameObject obj)
        {
            try
            {
                button = obj.transform;
                buttonSize = obj.transform.GetComponent<RectTransform>().sizeDelta;
            }
            catch (Exception error)
            {
                Debug.LogError(error);
            }
        }

        public float TopX()
        {
            print("333");
            if (button != null)
            {
                if (buttonSize.x >= 0)
                    return button.position.x;
                return button.position.x + buttonSize.x;
            }
            return 0;
        }

        public float TopY()
        {
            if (button != null)
            {
                if (buttonSize.y >= 0)
                    return button.position.y;
                return button.position.y + buttonSize.y;
            }
            return 0;
        }

        public float BottomX()
        {
            if (button != null)
            {
                if (buttonSize.x >= 0)
                    return button.position.x + buttonSize.x;
                return button.position.x;
            }
            return 0;
        }

        public float BottomY()
        {
            if (button != null)
            {
                if (buttonSize.y >= 0)
                    return button.position.y + buttonSize.y;
                return button.position.y;
            }
            return 0;
        }
    }

    private readonly ButtonPosition buttonLeft = new ButtonPosition();
    private readonly ButtonPosition buttonRight = new ButtonPosition();
    [SerializeField] private GameObject leftButtonArea, rightButtonArea;


    private void Start()
    {
        buttonLeft.GetButton(leftButtonArea);
        buttonRight.GetButton(rightButtonArea);
    }


    public bool IsClickedLeft()
    {
        print("OK");
        if (Input.touchCount > 0)
        {
            print("OK222");
            Touch touch = Input.GetTouch(0);
            if (InsideButtonArea(touch.position, buttonLeft))
                return true;
        }
        return false;
    }

    public bool IsClickedRight()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (InsideButtonArea(touch.position, buttonRight))
                return true;
        }
        return false;
    }


    private bool InsideButtonArea(Vector2 point, ButtonPosition button)
    {
        if (point.x > button.TopX() &&
            point.x < button.BottomX() &&
            point.y > button.TopY() &&
            point.y < button.BottomY())
            return true;
        return false;
    }
}
